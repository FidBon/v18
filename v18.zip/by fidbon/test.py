from Utils.OfferGenerator import OfferGenerator
from Utils.EventGenerator import EventGenerator
from colorama import Fore, Back, Style, init
init(autoreset=True)
from simple_term_menu import TerminalMenu
import time
import json
from Database.DatabaseManager import *
from Database.databasconnect import get_db_path

class new:
    def pls(self):
        self.player.Notifications = "yes"
        self.player.notifgems = gems


def new_offer(result):
    with open('JSON/offers.json', 'r',encoding='utf-8') as f:
       offers = json.load(f)
    offers[str(len(offers))] = result
    with open('JSON/offers.json', 'w',encoding='utf-8') as f:
       json.dump(offers, f, indent=4)

def main():
    #print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
    options = ["[1] Обновить магазин", "[2] Обновить эвенты", "[3] Добавить акцию", "[4] Изменить фон", "[5] Выдать покупку гемов","[6] Выход"]
    terminal_menu = TerminalMenu(options, title="SCREUtils\nv 0.1", clear_screen=True)
    main_menu_exit = False
    while not main_menu_exit:
        menu_entry_index = terminal_menu.show()
        
        if menu_entry_index == 0:
            
            off = OfferGenerator()
            try:
                off.updateOffers()
                print(Fore.GREEN + "Обновление магазина прошло успешно!\nВозвращение в главное меню через 5 сек.")
            except:
                print(Fore.RED + "Ошибка обновления магазиша\nВозвращение в главное меню через 5 сек.")
            time.sleep(5)

        if menu_entry_index == 1:

            off = EventGenerator()
            try:
                off.deleteEvents()
                off.generateEvents()
                print(Fore.GREEN + "Обновление игровых режимов прошло успешно!\nВозвращение в главное меню через 5 сек.")
            except:
                print(Fore.RED + "Ошибка обновления игровых режимов\nВозвращение в главное меню через 5 сек.")
            time.sleep(5)

        if menu_entry_index == 2:
            x = input("Введите аргументы так:\n<ID> <OfferTitle> <Cost> <OldCost> <Multiplier> <BrawlerID> <SkinID> <ShopType> <ShopDisplay>:\n")
            text = x.split()
            title = text[1]
            title = title.split("_")
            title = " ".join(title)
            print(title)
            result = {"ID": int(text[0]), "OfferTitle": title, "Cost": int(text[2]), "OldCost": int(text[3]), "Multiplier": int(text[4]), "BrawlerID": int(text[5]), "SkinID": int(text[6]), "WhoBuyed": [], "ShopType": int(text[7]), "ShopDisplay": int(text[8])}

            new_offer(result)
            print(Fore.GREEN + "Новая акция была успешно добавлена!\nВозвращение в главное меню через 5 сек.")
            time.sleep(5)

        if menu_entry_index == 3:
        	x = int(input("Выбери ID темы\n0 - Обычная\n1 - Новый год (Снег)\n2 - Красный новый год\n3 - От клеш рояля\n5 - Желтые панды\n6 - Фиолетовый булл\n7 - Роботы Зелёный фон:\n"))
        	with open('Logic/theme.txt', 'w',encoding='utf-8') as f:
        		f.write(str(x))

        	print(Fore.GREEN + "Новая фон был поставлен в меню!\nВозвращение в главное меню через 5 сек.")
        	time.sleep(5)

        if menu_entry_index == 4:
            x = input("Введите аргументы так:\n<ID игрока> <число гемов>:\n")
            global gems
            lowid = int(x[0])
            gems = int(x[1])

            con = get_db_path()
            with con.cursor() as cursor:
                
                sql = f'UPDATE `players` SET `Notifications`= "yes" WHERE lowID = {lowid}'
                cursor.execute(sql)
                con.commit()
                sql = f'UPDATE `players` SET `notifgems`= "{gems}" WHERE lowID = {lowid}'
                cursor.execute(sql)
                con.commit()
                classs = new()
                new.pls()

                print(Fore.GREEN + "Успешно!\nВозвращение в главное меню через 5 сек.")
                time.sleep(5)

        if menu_entry_index == 5:
            print("Exit")
            main_menu_exit = True

    
main()