from Database.DatabaseManager import DataBase
import sqlite3 as sql
import json, random

class Slots:
    def __init__(self, client, player):
        self.player = player

    def createSlot(self):
        self.conn = sql.connect("Logic/Battle/Matchmake/slots.db")
        self.cur = self.conn.cursor()
        self.cur.execute("CREATE TABLE IF NOT EXISTS slots (ID INT, players JSON, count INT)")
        self.conn.commit()
        data = {"0": {"lowID": self.player.low_id, "brawlerID": self.player.brawler_id, "skinID": self.player.skin_id, "name": self.player.name}}
        self.player.matchmake_id = random.randint(0, 99999999)
        var = self.player.matchmake_id, json.dumps(data), 1
        self.cur.execute("INSERT INTO slots VALUES (?,?,?)", var)
        self.conn.commit()
        self.conn.close()

    def addPlayer(self):
        self.conn = sql.connect("Logic/Battle/Matchmake/slots.db")
        self.cur = self.conn.cursor()
        try:
            self.cur.execute(f"SELECT * FROM slots WHERE count != {self.player.mmplayers}")
            fetch = self.cur.fetchall()
            if fetch:
                for i in fetch:
                    self.player.matchmake_id = fetch[0][0]
                    plrData = json.loads(i[1])
                    l = str(len(plrData))
                    plrData[l] = {}
                    plrData[l]["lowID"] = self.player.low_id
                    plrData[l]["brawlerID"] = self.player.brawler_id
                    plrData[l]["skinID"] = self.player.skin_id
                    plrData[l]["name"] = self.player.name
                    self.cur.execute("UPDATE slots SET players=? WHERE ID=?", (json.dumps(plrData), fetch[0][0]))
                    self.conn.commit()
                    self.battleCount = len(plrData)
                    self.plrData = plrData
                    self.cur.execute("UPDATE slots SET count=? WHERE ID=?", (self.battleCount, fetch[0][0]))
                    self.conn.commit()
                    return 1
        except Exception as e:
            print(e)
            return 0

    def deletePlayer(self):
        self.conn = sql.connect("Logic/Battle/Matchmake/slots.db")
        self.cur = self.conn.cursor()
        self.cur.execute("SELECT * FROM slots WHERE ID=?", (self.player.matchmake_id,))
        fetch = self.cur.fetchall()
        if fetch:
            plrData = json.loads(fetch[0][1])
            for i in plrData:
                if plrData[i]["lowID"] == self.player.low_id:
                    plrData.pop(str(i))
                    self.cur.execute("UPDATE slots SET players=? WHERE ID=?", (json.dumps(plrData), fetch[0][0]))
                    self.conn.commit()
                    self.battleCount = len(plrData)
                    if self.battleCount == 0:
                        self.cur.execute("DELETE FROM slots WHERE ID=?", (fetch[0][0],))
                    else:
                        self.cur.execute("UPDATE slots SET count=? WHERE ID=?", (self.battleCount, fetch[0][0]))
                    self.conn.commit()
                    break

    def checkCount(self):
        self.conn = sql.connect("Logic/Battle/Matchmake/slots.db")
        self.cur = self.conn.cursor()
        self.cur.execute("SELECT * FROM slots WHERE ID=?", (self.player.matchmake_id,))
        fetch = self.cur.fetchall()
        if fetch:
            self.battleCount = fetch[0][2]
        return self.battleCount

    def getPlayers(self):
        self.conn = sql.connect("Logic/Battle/Matchmake/slots.db")
        self.cur = self.conn.cursor()
        try:
            self.cur.execute("SELECT * FROM slots WHERE ID=?", (self.player.matchmake_id,))
        except:
            self.cur.execute("SELECT * FROM slots WHERE ID=?", (self.player.battle_id,))
        fetch = self.cur.fetchall()
        if fetch:
            plrs = json.loads(fetch[0][1])
            self.plrData = plrs
        return self.plrData