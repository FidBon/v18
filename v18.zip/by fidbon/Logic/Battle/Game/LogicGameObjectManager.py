from Utils.BitStream import BitStream
from Utils.Writer import Writer 
from Logic.Battle.Game.LogicCharacter import LogicCharacter

class LogicGameObjectManager:
	def encode(self, stream):
		stream.writePositiveInt(1000000 + 0, 21)
		stream.writePositiveVInt(0, 4) # 0 - Нормальная игра, 1 - В погоню за врагом!
		stream.writePositiveInt(20, 1)
		stream.writeInt(-1, 4) # понос

		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(1, 1)
		stream.writePositiveInt(1, 1)
		stream.writePositiveInt(1, 1)

		stream.writePositiveInt(0, 5)
		stream.writePositiveInt(0, 6)
		stream.writePositiveInt(0, 5)
		stream.writePositiveInt(0, 6)

		stream.writePositiveInt(1, 1)
		stream.writePositiveInt(1, 1)
		stream.writePositiveInt(0, 1)
		stream.writeBoolean(True)

		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 12)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(1, 1)


		for i in range(6):
			stream.writePositiveInt(0, 1)
			stream.writePositiveInt(0, 1)

		stream.writePositiveInt(0, 4) # unknown dudka
		LogicCharacter.encode(self, stream)

		self.writeInt(stream.size())
		self.writeBytes(stream.getBuff())