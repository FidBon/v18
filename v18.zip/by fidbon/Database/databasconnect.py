import pymysql

def get_db_path():
    return pymysql.connect(
  host=('127.0.0.1'),
  user=("newuser"),
  password=("1234567890"),
  database=('r')) #название бд
def get_club_id(low_id):
 return