from ast import excepthandler
from random import *
from Database.DatabaseManager import DataBase
from Packets.Commands.Server.LogicBoxGenerator import Gen

from Utils.Writer import Writer


class LogicBoxDataCommand(Writer):

    def __init__(self, client, player, state, count):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.state = state
        self.count = count

    def encode(self):
        def get_id(id):
            if id == 5:  # Brawl Box         
                return 10
            elif id == 4:  # Big Box
                return 12
            elif id == 3:  # Shop Mega Box
                return 11
            elif id == 1:  # Shop Big Box
                return 12
            elif id == 0:  # Trophy Road Brawl Box
                return 10

        self.box_skin_id = get_id(self.player.box_id)
        if self.box_skin_id == 10:
            box = 1
        elif self.box_skin_id == 11:
            box = 10
        elif self.box_skin_id == 12:
            box = 3
        rews = Gen.GeneratorLoot(self, box)
        cards = 0
        rewards = rews["rewards"]
        

        # Box info
        self.writeVint(203) # CommandID
        self.writeVint(self.count)   # Unknown
        self.writeVint(1)   # Unknown
        self.writeVint(self.box_skin_id)  # BoxID
        # Box info end

        # Reward start
        self.writeVint(rewards) # Reward count
        if rews["Gold"] > 0:
            self.writeVint(rews["Gold"]) # Reward amount
            self.writeVint(0) # CsvID 16
            self.writeVint(7) # Reward ID
            self.writeVint(0) # CsvID 29
            self.writeVint(0) # CsvID 52
            self.player.gold += rews["Gold"]
            DataBase.replaceValue(self, "gold", self.player.gold)
        for i in range(len(rews["Points"])):
            self.writeVint(int(rews["Points"][i]["multiplier"])) # Reward amount
            self.writeScId(16, int(rews["Points"][i]["brawler"])) # CsvID 16
            self.writeVint(6) # Reward ID
            self.writeVint(0) # CsvID 29
            self.writeVint(0) # CsvID 52
            self.player.brawlers_upgradium[str((rews["Points"][i]["brawler"]))] += rews["Points"][i]["multiplier"]
            DataBase.replaceValue(self, 'brawlersUpgradePoints', self.player.brawlers_upgradium)
        for i in range(len(rews["brawlers"])):
            self.writeVint(1)                           # Reward amount
            self.writeScId(16, int(rews["brawlers"][i]))  # CsvID 16
            self.writeVint(1) # Reward ID
            self.writeVint(0) # CsvID 29
            self.writeVint(0) # CsvID 52 
            self.player.BrawlersUnlockedState[str(rews["brawlers"][i])] = 1
            DataBase.replaceValue(self, 'UnlockedBrawlers', self.player.BrawlersUnlockedState)
        for i in range(len(rews["starpower"])):
            self.writeVint(1)                           # Reward amount
            self.writeScId(16, int(rews["starpower"][i]))  # CsvID 16
            self.writeVint(4) # Reward ID
            self.writeVint(0) # CsvID 29
            self.writeVint(0) # CsvID 52 
            self.player.Brawler_starPower[str(rews["starpower"][i])] = 1
            DataBase.replaceValue(self, 'brawlerStarPower', self.player.Brawler_starPower)
        if rews["bonuses"][0]["multiplier"] > 0:
            self.writeVint(rews["bonuses"][0]["multiplier"]) # Reward ammount
            self.writeScId(0, 8) # RewardID
            self.writeVint(0)
            self.writeVint(0)
            self.player.gems += rews["bonuses"][0]["multiplier"]
            DataBase.replaceValue(self, "gems", self.player.gems)
            DataBase.loadAccount(self)
        else:
            pass
        if rews["bonuses"][1]["multiplier"] > 0:
            self.writeVint(rews["bonuses"][1]["multiplier"]) # Reward ammount
            self.writeScId(0, 2) # RewardID
            self.writeVint(0)
            self.writeVint(0)
            self.player.tokensdoubler += rews["bonuses"][1]["multiplier"]
            DataBase.replaceValue(self, "tokensdoubler", self.player.tokensdoubler)
        else:
            pass
        if rews["bonuses"][2]["multiplier"] > 0:
            self.writeVint(rews["bonuses"][2]["multiplier"]) # Reward ammount
            self.writeScId(0, 3) # RewardID
            self.writeVint(0)
            self.writeVint(0)
            self.player.tickets += rews["bonuses"][2]["multiplier"]
            DataBase.replaceValue(self, "tickets", self.player.tickets)
        else:
            pass
        # Box end
        if self.state == 1:
            self.writeVint(self.player.trophy_road)
        else:
            self.writeVint(0)
