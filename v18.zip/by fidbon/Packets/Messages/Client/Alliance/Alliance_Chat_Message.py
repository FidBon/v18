import json
import pymysql
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.AllianceBot.Alliance_Bot_Chat_Server_Message import AllianceBotChatServerMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage

from Database.DatabaseManager import DataBase
from Utils.Reader import BSMessageReader

# Подключение к базе данных
def get_mysql_connection():
    return pymysql.connect(
        host='127.0.0.1',
        user='newuser',
        password='1234567890',
        db='rumblebrawl',
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor  # Используем DictCursor для возврата результатов в виде словарей
    )

class AllianceChatMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.bot_msg = ''
        self.send_ofs = False
        self.IsAcmd = False

    def decode(self):
        self.msg = self.read_string()
        self.args = self.msg.strip().split()
        self.command = self.args[0]
        
        if self.command == "/theme":
            self.IsAcmd = True
            if self.player.vip:
                if len(self.args) == 2:
                    self.args[1] = int(self.args[1])
                    if self.args[1] > -1 and self.args[1] < 26 and self.args[1] != 5:
                        DataBase.replaceValue(self, 'theme', self.args[1])
                        self.send_ofs = True
                    else:
                        self.bot_msg = "Указанного фона не существует!"
                else:
                    self.bot_msg = "Укажите айди темы!\nВсе доступные темы:\n0 - Дефолт тема\n1 - LNY\n2 -  Golden Week (фон с собаками)\n3 - Ретрополис\n4 - Меха\n6 - Фон с пиратами\n7 - LNY20 (Аркадное обновление)\n8 - PSG\n9 - SC10 (10 лет supercell)\n10 - Базар тары\n11 - Суперсити\n12 - Старр парк\n13 - Лунный фестиваль\n14 - Мировой финал 2020\n15 - Хэллоуин 2020\n16 - Зимний фон (Веселые каникулы)\n17 - Зимний фон (с партиклами)\n18 - Коспоопера старр\n19 - LNY21\n20 - ActionShow\n21 - Ramadan\n22 - Дефолт тема\n23 - Пляж\n24 - Punk\n25 - ColetteBrawl [Custom]"
            else:
                self.bot_msg = "У вас нет VIP!"
        elif self.command == "/help":
            self.IsAcmd = True
            self.bot_msg = f"Команды:\n/help - показывает информацию об аккаунте\n/promo <код> - ввести промокод"
        elif self.command == "/info":
            self.IsAcmd = True
            self.bot_msg = f"Имя: {self.player.name}\nКол-во трофеев: {self.player.trophies}\nvВип: {self.player.vip}\nВаш ID: {self.player.low_id}\nТокен: {self.player.token}"
        elif self.command == "/promo":
            self.IsAcmd = True
            if len(self.args) == 2:
                code = self.args[1]
                self.process_promo_code(code)
            else:
                self.bot_msg = "Используйте: /promo <код>"

    def process_promo_code(self, code):
        with open('promo_codes.json', 'r') as file:
            promo_codes = json.load(file)

        code_found = False
        for key, value in promo_codes.items():
            if code in value['codes'] and not None:
                code_found = True
                if self.check_code_activation(code):
                    self.bot_msg = f"Промокод активирован! Вы получили {value['amount']} кристаллов.\nДля применения изменений перезайдите."
                    self.add_gems(value['amount'])
                    self.record_code_activation(code)
                    self.decrease_code_activation(key)
                else:
                    self.bot_msg = "Этот промокод уже использован максимальное количество раз."
                break
        
        if not code_found:
            self.bot_msg = "Неверный промокод."

    def check_code_activation(self, code):
        conn = get_mysql_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT promo FROM players WHERE lowID = %s", (self.player.low_id,))
            result = cursor.fetchone()
            if result:
                promo_codes = result['promo']
                if code in promo_codes:
                    return False
                else:
                    return True
            else:
                return True
        finally:
            conn.close()

    def record_code_activation(self, code):
        conn = get_mysql_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("UPDATE players SET promo = JSON_SET(IFNULL(promo, '{}'), '$.promo', %s) WHERE lowID = %s", (code + ';', self.player.low_id))
                conn.commit()
        finally:
            conn.close()

    def decrease_code_activation(self, key):
        with open('promo_codes.json', 'r') as file:
            promo_codes = json.load(file)
        
        if promo_codes[key]['activations'] > 1:
            promo_codes[key]['activations'] -= 1
        else:
            promo_codes[key]['codes'].remove(key)

        with open('promo_codes.json', 'w') as file:
            json.dump(promo_codes, file, indent=4)

    def add_gems(self, amount):
        conn = get_mysql_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("UPDATE players SET gems = gems + %s WHERE lowID = %s", (amount, self.player.low_id))
                conn.commit()
        finally:
            conn.close()

    def process(self):
        if self.send_ofs == False and self.IsAcmd == False:
            DataBase.Addmsg(self, self.player.club_low_id, 2, 0, self.player.low_id, self.player.name, self.player.club_role, self.msg)
            DataBase.loadClub(self, self.player.club_low_id)
            for i in self.plrids:
                AllianceChatServerMessage(self.client, self.player, self.msg, self.player.club_low_id).sendWithLowID(i)
                DataBase.DeleteAllMsg(self, self.player.club_low_id)

        if self.bot_msg != '':
            AllianceChatServerMessage(self.client, self.player, self.msg, self.player.club_low_id, True).send()
            AllianceBotChatServerMessage(self.client, self.player, self.bot_msg).send()

        if self.send_ofs:
            self.player.err_code = 1
            LoginFailedMessage(self.client, self.player, 'Всё готово! Если айди правильный, то при следующем заходе в игру будет загружен привязанный к нему аккаунт').send()