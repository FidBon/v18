from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Utils.Reader import BSMessageReader
from Utils.Helpers import Helpers

class TeamMemberStatusMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.player.status = self.read_Vint()

    def process(self):
        for i in Helpers.rooms:
            if i["roomID"] == self.player.room_id:
                for player in i["plrs"]:
                    if player['id'] == self.player.low_id:
                        player["state"] = self.player.status
                for player in i["plrs"]:
                    TeamGameroomDataMessage(self.client, self.player).sendWithLowID(player["id"])
                break