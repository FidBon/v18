from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class GetLeaderboardGlobalOkMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24403
        self.player = player

    def encode(self):
        self.indexOfPlayer = 1
        self.writeVint(1)
        self.writeVint(0) # SCID
        self.writeString()

        fetch = DataBase.getLeaders(self)
        x=1
        self.writeVint(len(fetch)) # Players Count

        for i in fetch:
            if i[0] == self.player.low_id:
                x = fetch.index(i) + 1
            self.writeVint(0) # High ID
            self.writeVint(i[0]) # Low ID

            self.writeVint(1)
            self.writeVint(i[2]) # Player Trophies

            self.writeVint(1)

            if i[7] != "none":
                titul = i[7]
            else:
                titul = ""

            if i[5] != 0:
                DataBase.loadClubName(self, i[5])
                self.writeString(self.clubName)


            else:
                self.writeString()
            if i[6] == 1:
                self.writeString(f"<cffff00>[LITE]</c> {i[1]} {titul}")
            elif i[6] == 2:
                self.writeString(f"<c43ff00>[<c87ff00>V<ccbff00>I<cccff00>P<cddff00>]</c> {i[1]} {titul}")
            elif i[6] == 3:
                 self.writeString(f"<c00f2ff>[<c00e5ff>P<c00d8ff>R<c00cbff>E<c00bfff>M<c00bfff>I<c0098ff>U<c0072ff>M<c004cff>]</c> {i[1]} {titul}")
            elif i[6] == 4:
                 self.writeString(f"<cd6fd00>[<ce0fb00>М<ceafa00>Е<cf4f800>Д<cfff700>И<cfff700>Й<cffed00>К<cffe400>А<cffda00>]</c> {i[1]}")
            elif i[6] == 5:
                 self.writeString(f"<cff2a00>[<cff5400>С<cff7f00>О<cffa900>З<cffd400>Д<cfefe00>А<cffff00>Т<cd4ff00>Е<caaff00>Л<c7fff00>Ь<c55ff00>] {i[1]} {titul}")
            else:
                self.writeString(f"{i[1]} {titul}") # Player Name

            self.writeVint(1) # Player Level
            self.writeVint(28000000 + i[3])
            self.writeVint(43000000 + i[4])
            self.writeVint(0)


        self.writeVint(0)
        self.writeVint(x)
        self.writeVint(1)
        self.writeVint(0) # Leaderboard global TID
        self.writeString("RU")