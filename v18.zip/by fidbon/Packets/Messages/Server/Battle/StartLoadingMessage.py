from Utils.Writer import Writer


class StartLoadingMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 20559
        self.client = client
        self.player = player


    def encode(self):
        self.writeInt(1) # Game Mode Total Players
        self.writeInt(0)
        self.writeInt(0)

        # Logic Player Array
        self.writeInt(1) # Players Count
        
        self.writeInt(0) #High ID
        self.writeInt(1) #Low ID
        self.writeString("Nost Brawl")
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeInt(30) #unk
        
        self.writeScId(16, 0)
        self.writeScId(29, 0)
        self.writeByte(0)

        self.writeInt(0) # Array

        self.writeInt(0) # Count

        self.writeInt(1000) # Unknown

        self.writeVint(1)
        self.writeVint(1) # Map Blocks
        self.writeVint(1) # Joystick Mode

        self.writeVint(1)
        self.writeVint(0)
        self.writeVint(0)

        self.writeScId(15, 7) # Location ID
        
        print("StartLoading was sended")
        