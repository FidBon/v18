from Utils.Writer import Writer
from Database.DatabaseManager import DataBase

class FriendListMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 20105
        self.player = player

    def encode(self):
        try:
            data = DataBase.getFriends(self)
        except:
            data = []
        self.writeVint(len(data)) # Friends Count
        self.writeVint(0) # Games Played Together

        for i in data:
            i = json.loads(i)
            self.friend = DataBase.loadById(self, i["lowID"])
            self.writeInt(0)  # HighID
            self.writeInt(self.friend[4])  # LowID

            self.writeString()
            self.writeString()
            self.writeString()
            self.writeString()
            self.writeString()
            self.writeString()

            self.writeInt(self.friend[19])  # Trophies
            self.writeInt(4)  # Friend state 0 = friend, 1 = not friend, 2 = request sent, 3 = you have an invite from him??, 4 = friend list
            self.writeInt(1)
            self.writeInt(1)
            self.writeInt(1)

            self.writeBoolean(False)

            self.writeString()
            self.writeInt(0)

            self.writeBoolean(True)  # ?? is a player?

            self.writeString(self.friend[4])
            self.writeVint(100)
            self.writeVint(28000005)
            self.writeVint(43000002)
            self.writeVint(0)
