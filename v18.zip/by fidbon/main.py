from colorama import Fore, Back, Style
print(Fore.MAGENTA + """
  ___  ____  ___ ____ ___ _   _    _    _
 / _ \|  _ \|_ _/ ___|_ _| \ | |  / \  | |
| | | | |_) || | |  _ | ||  \| | / _ \ | |
| |_| |  _ < | | |_| || || |\  |/ ___ \| |___
 \___/|_| \_\___\____|___|_| \_/_/   \_\_____|

 ____  _____ ______     _______ ____  ____
/ ___|| ____|  _ \ \   / / ____|  _ \/ ___|
\___ \|  _| | |_) \ \ / /|  _| | |_) \___ \
 ___) | |___|  _ < \ V / | |___|  _ < ___) |
|____/|_____|_| \_\ \_/  |_____|_| \_\____/
 """)
print(Fore.RED + '[INFO] | Server starting...')
from datetime import datetime
from threading import Thread
import socket, asyncio, uvloop, sys, time, os

from Logic.Device import Device
from Logic.Player import Players
from Utils.Config import Config
from Utils.OfferGenerator import OfferGenerator
from Utils.EventGenerator import EventGenerator
from Utils.Helpers import Helpers

from Packets.LogicMessageFactory import packets
from Database.DatabaseManager import DataBase

class Server:
    Clients = {"ClientCounts": 0, "Clients": {}}

    def __init__(self, ip: str, port: int):
        self.server = socket.socket()
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, True)
        self.port = port
        self.ip = ip
        self.conns = {}
        self.conns_expire = {}
    
    def dailyTimer(self):
        while True:
            if datetime.now().hour == 0 and datetime.now().minute == 0:
                OfferGenerator.deleteOffers(self)
                OfferGenerator.generateOffers(self)
                EventGenerator.deleteEvents(self)
                EventGenerator.generateEvents(self)
                time.sleep(60)
            else:
                time.sleep(5)

    async def start(self):
        if not os.path.exists('./config.json'):
            print("Creating config.json...")
            Config.create_config(self)

        thread = Thread(target = Server.dailyTimer, args = (self, ))
        thread.start()
        
        self.server.bind((self.ip, self.port))
        print(Fore.MAGENTA + f"\n[INFO] | Server started {self.ip}:{self.port}.")
        self.server.listen()
        self.server.setblocking(False)

        loop = asyncio.get_event_loop()
        asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())

        while True:
            client, address = await loop.sock_accept(self.server)
            count = self.conns.get(address[0], None)
            count_expire = self.conns_expire.get(address[0], None)
            if count and count_expire and count_expire > time.time():
                if count == 2:
                    os.system(f"sudo iptables -t filter -A INPUT -s {address[0]} -j DROP")
                    os.system("sudo netfilter-persistent save")
                    client.close()
                    print(Fore.RED + f'[DDoS!] VDS IP: {address[0]}')
                    continue
                else:
                    self.conns[address[0]] = count + 1
            else:
                self.conns[address[0]] = 1
                self.conns_expire[address[0]] = time.time() + 10
                print(Fore.CYAN + f'[INFO] | New connect! IP: {address[0]}')
            loop.create_task(ClientThread(client, address).start())
            Helpers.PlayersCount += 1
            print(Fore.CYAN + f"[INFO] | Players Online: {Helpers.PlayersCount}")

class ClientThread:
	def __init__(self, client, address):
		self.client = client
		self.address = address
		self.device = Device(self.client)
		self.player = Players(self.device)

	async def recvall(self, length: int, loop):
		data = b''
		while len(data) < length:
			s = await loop.sock_recv(self.client, length)
			if not s:
				self.client.close()
				break
			data += s
		return data

	async def start(self):
		loop = asyncio.get_event_loop()
		last_packet = time.time()
		try:
			while True:
				header = await loop.sock_recv(self.client, 7)
				if len(header) > 0:
					last_packet = time.time()
					packet_id = int.from_bytes(header[:2], 'big')
					length = int.from_bytes(header[2:5], 'big')
					data = await self.recvall(length, loop)

					if packet_id in packets:
						print(Fore.YELLOW + f'[PACKET] | {packets[packet_id](self.client, self.player, data).__class__.__name__} Packet has been send! ID: {packet_id}. Length: {length}\n')
						message = packets[packet_id](self.client, self.player, data)
						message.decode()
						message.process()

						if packet_id == 10101:
							Server.Clients["Clients"][str(self.player.low_id)] = {"SocketInfo": self.client}
							Server.Clients["ClientCounts"] = Helpers.PlayersCount
							self.player.ClientDict = Server.Clients

					else:
						pass

				else:
					print(Fore.CYAN + f"[INFO] | IP: {self.address[0]} disconnected!\n")
					DataBase.replaceValue(self, "online", 0)
					self.client.close()
					Helpers.PlayersCount -= 1
					break
		except ConnectionAbortedError:
			print(Fore.CYAN + f"[INFO] | IP: {self.address[0]} disconnected!\n")
			DataBase.replaceValue(self, "online", 0)
			self.client.close()
			Helpers.PlayersCount -= 1
		except ConnectionResetError:
			print(Fore.CYAN + f"[INFO] | IP: {self.address[0]} отключился!\n")
			DataBase.replaceValue(self, "online", 0)
			self.client.close()
			Helpers.PlayersCount -= 1
		except TimeoutError:
			print(Fore.CYAN + f"[INFO] | IP: {self.address[0]} отключился!\n")
			DataBase.replaceValue(self, "online", 0)
			self.client.close()
			Helpers.PlayersCount -= 1
		except OSError:
			pass

if __name__ == '__main__':
    server = Server("0.0.0.0", 9337)
    try:
        asyncio.run(server.start())
    except KeyboardInterrupt:
        DataBase.replaceValues()
        print(Fore.RED + "\n[INFO] | The server has stopped. Press CTRL+C again to access the console")
        exit()